// ... (previous JavaScript code)

document.addEventListener("DOMContentLoaded", function () {
    const display = document.getElementById("display");
    const numberButtons = document.querySelectorAll(".number");
    const operatorButtons = document.querySelectorAll(".operator");
    const clearButton = document.getElementById("clear");
    const equalsButton = document.getElementById("equals");
    const cancelButton = document.getElementById("cancel");
    const clearAllButton = document.getElementById("clearAll");

    // ... (previous code)

    cancelButton.addEventListener("click", function () {
        currentValue = "";
        updateDisplay();
    });

    clearAllButton.addEventListener("click", function () {
        currentValue = "";
        currentOperator = "";
        previousValue = "";
        updateDisplay();
    });

    // ... (rest of your code)
});


    let currentValue = "";
    let currentOperator = "";
    let previousValue = "";

    function updateDisplay() {
        display.value = currentValue;
    }

    numberButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            currentValue += button.textContent;
            updateDisplay();
        });
    });

    operatorButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            if (currentValue !== "") {
                if (previousValue !== "") {
                    calculate();
                } else {
                    previousValue = currentValue;
                    currentValue = "";
                }
                currentOperator = button.textContent;
            }
        });
    });

    equalsButton.addEventListener("click", calculate);

    clearButton.addEventListener("click", function () {
        currentValue = "";
        currentOperator = "";
        previousValue = "";
        updateDisplay();
    });

    function calculate() {
        if (currentValue !== "" && previousValue !== "") {
            const num1 = parseFloat(previousValue);
            const num2 = parseFloat(currentValue);
            if (currentOperator === "+") {
                currentValue = (num1 + num2).toString();
            } else if (currentOperator === "-") {
                currentValue = (num1 - num2).toString();
            } else if (currentOperator === "*") {
                currentValue = (num1 * num2).toString();
            } else if (currentOperator === "/") {
                currentValue = (num1 / num2).toString();
            }
            previousValue = "";
            currentOperator = "";
            updateDisplay();
        }
    }
});
