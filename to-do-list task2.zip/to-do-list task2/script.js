document.addEventListener("DOMContentLoaded", function () {
    const taskInput = document.getElementById("taskInput");
    const addTaskBtn = document.getElementById("addTaskBtn");
    const taskList = document.getElementById("taskList");

    // Load tasks from local storage
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    function saveTasks() {
        localStorage.setItem("tasks", JSON.stringify(tasks));
    }

    function renderTasks() {
        taskList.innerHTML = "";
        tasks.forEach(function (task, index) {
            const li = document.createElement("li");
            li.innerHTML = `
                <span>${task}</span>
                <button class="deleteBtn" data-index="${index}">Delete</button>
            `;
            taskList.appendChild(li);
        });

        // Add event listeners to delete buttons
        const deleteButtons = document.querySelectorAll(".deleteBtn");
        deleteButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                const index = button.getAttribute("data-index");
                tasks.splice(index, 1);
                saveTasks();
                renderTasks();
            });
        });
    }

    addTaskBtn.addEventListener("click", function () {
        const newTask = taskInput.value.trim();
        if (newTask !== "") {
            tasks.push(newTask);
            saveTasks();
            taskInput.value = "";
            renderTasks();
        }
    });

    renderTasks();
});
